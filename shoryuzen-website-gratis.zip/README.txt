# Shoryuzen Landing Page

Website landing page responsif, dibuat tanpa framework dan tanpa biaya hosting khusus.

## Yang perlu diganti
Buka `index.html`, lalu cari:
- `Shoryuzen` → nama bisnis
- `6281234567890` → nomor WhatsApp tujuan (format internasional, tanpa +)
- `Jakarta Selatan, DKI Jakarta` → lokasi
- teks layanan → isi bisnis Anda

## Hosting gratis
Bisa dipasang di GitHub Pages, Netlify, atau Cloudflare Pages.

File utama: `index.html`
